import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountinformation',
  templateUrl: './accountinformation.component.html'
})
export class AccountinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
