import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basicinformation',
  templateUrl: './basicinformation.component.html'
})
export class BasicinformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
