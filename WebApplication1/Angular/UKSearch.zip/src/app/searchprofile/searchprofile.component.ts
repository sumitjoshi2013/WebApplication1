import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchprofile',
  templateUrl: './searchprofile.component.html'
})
export class SearchprofileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
